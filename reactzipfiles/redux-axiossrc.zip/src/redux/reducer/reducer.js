import { GET_DETAILS, POST_DETAILS, UPDATE_DETAILS } from "../type";
const initialstate = {
    details:[],
    isResponse : false,
    isUpdateResponse: false
};

const Reducer  =(state = initialstate,action) =>{
    switch(action.type){
        case GET_DETAILS:
            return {
                details : action.payload,
            }
            case POST_DETAILS:
            return {
                isResponse : action.payload,
            }
            case UPDATE_DETAILS:
            return {
                isUpdateResponse : action.payload,
            }
        default:
            return state;            
    }
};

export default Reducer;