import Reducer from "./reducer";

import {combineReducers} from 'redux';

const RootReducer = combineReducers({
    Reducer,
});

export default RootReducer;