  import React from 'react';
  import './App.css';
  import Home from './components/Home';
  import Forms from './components/Forms';
  import { BrowserRouter as Router, Route, Link, Routes } from 'react-router-dom';
import UpdateDetails from './components/updateDetails';



  const App = () => {
    return (
      
<Router>
<div className="App">
  <Routes>
  <Route path="/" element={<Home/>}></Route>
  <Route path="form" element={<Forms/>}/>
  <Route path="update/:id" element={<UpdateDetails/>}/>
  </Routes>
  
  

      </div>
      </Router>
    );
  }

  export default App;
