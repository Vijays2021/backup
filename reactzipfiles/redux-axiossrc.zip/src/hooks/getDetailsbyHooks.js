import React,{ useEffect, useState } from "react";
import { GetApiDetailsByID } from "../api/axiosRequest";


export default (props)=>{
    const [detailsById, setDetailsById] = useState({})
const GetDetailsByHooks = (requsetId) =>{

        return GetApiDetailsByID(requsetId).then((res)=>{
            console.log("Response Data is _____", res);
            setDetailsById(res);
        });   
};
useEffect(()=>{
    GetDetailsByHooks(props)
},[])
    return [detailsById]

}


