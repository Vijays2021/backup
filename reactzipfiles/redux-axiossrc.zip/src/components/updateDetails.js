import React, { useState, useEffect } from 'react';
import {PostApiAction , UpdateApiAction} from '../redux/action/action';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import getDetailsbyHooks from '../hooks/getDetailsbyHooks';

const UpdateDetails = () => {
    const {id} =useParams();
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [phone, setPhone] = useState("");
    const [country, setCountry] = useState("");
   
    const dispatch = useDispatch();
    const isUpdateResponse = useSelector(state => state.Reducer.isUpdateResponse);

const [detailsById] = getDetailsbyHooks(id)
const nameHandler =(e) => {
    setName(e.target.value)
} 

const emailHandler =(e) => {
    setEmail(e.target.value)
}
const phoneHandler =(e) => {
    setPhone(e.target.value)
}
const countryHandler =(e) => {
    setCountry(e.target.value)
}

const clickHandler =(e) =>{
    e.preventDefault();
    const  finalData ={
        name:name,
        email,email,
        phone:phone,
        country:country
    }
    dispatch(UpdateApiAction(finalData, id));


};

useEffect(()=>{
    const data = ()=>{
        if(detailsById.data){
            setName(detailsById.data.name)
            setEmail(detailsById.data.email)
            setPhone(detailsById.data.phone)
            setCountry(detailsById.data.country)
        }
    };
    data()
},[detailsById.data]);

if(isUpdateResponse){
    alert("Contact has been updated !");
}

    return (
        <div>
            <form>
                <div>
                    <div className="form-row">
                        <div className="form-group col-md-6">
                            <label htmlFor="inputName">Name</label>
                            <input type="text" 
                            className="form-control" 
                            id="inputName" placeholder="Name"
                            onChange={(e)=>nameHandler(e)}
                            defaultValue={name} />
                        </div>
                        <div className="form-group col-md-6">
                            <label htmlFor="inputEmail">Email</label>
                            <input type="email" 
                            className="form-control" 
                            id="inputEmail" placeholder="Email" 
                            onChange={(e)=>emailHandler(e)} 
                            defaultValue={email}/>
                        </div>
                        <div className="form-group col-md-6">
                            <label htmlFor="inputPhone">Phone</label>
                            <input type="text" 
                            className="form-control" 
                            id="inputPhone" placeholder="Phone"
                            onChange={(e)=>phoneHandler(e)}
                            defaultValue={phone} />
                        </div>
                        <div className="form-group col-md-6">
                            <label htmlFor="inputCountry">Country</label>
                            <input type="text" 
                            className="form-control" 
                            id="inputCountry" placeholder="Country"
                            onChange={(e)=>countryHandler(e)}
                            defaultValue={country} />
                        </div>



                        <button type="submit" className="btn btn-primary" onClick={(e)=>{clickHandler(e)}}>Update</button>
                    </div>
                </div>
                </form>
                </div>
                )
}

                export default UpdateDetails;