import logo from './logo.svg';
import './App.css';

import Users from './components/Users';

function App() {
  return (
    <div className="App">
       <h1>Redux Tutorial</h1>
         <Users/>
    </div>
  );
}

export default App;
