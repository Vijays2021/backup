import React, { Component } from "react";  

import PropTypes from 'prop-types';  
import { getEmployees } from './Action';  
import { connect } from 'react-redux';  
  
class Employee extends Component {  
  constructor(props) {  
    super(props);  
    this.state = {  
      id: 0,  
      employeeName: "",  
      employeeDepartment: ""  
    };  
  }  
  
  static propTypes = {  
    employees: PropTypes.array.isRequired,  
    getEmployees: PropTypes.func.isRequired,  
    addEmployee: PropTypes.func.isRequired,  
    editEmployee: PropTypes.func.isRequired,  
    deleteEmployee: PropTypes.func.isRequired  
  };  
  
  componentDidMount() {  
    this.props.getEmployees();  
  }  
  
  
  handleNameChange = (e) => {  
    this.setState({  
      employeeName: e.target.value  
    });  
  }  
  
  handleDepartmentChange = (e) => {  
    this.setState({  
      employeeDepartment: e.target.value  
    });  
  }  
  
  clearData = () => {  
    this.setState({  
      id: 0,  
      employeeName: "",  
      employeeDepartment: ""  
    });  
  }  
  
  render() {  
    return (  
      <div className="App">  
        {/* <header className="App-header">   */}

          <h1 className="App-title">CRUD opeartions for Employee Module</h1>  
        {/* </header>   */}
        <br/>
        <p className="App-intro">  
          <div className="leftsection"> 
          <table className="table-center">
            Employee Name : <input onChange={this.handleNameChange} value={this.state.employeeName} type="text" placeholder="Employee Name" /> <br />  <br/>
            Employee Department :  <input onChange={this.handleDepartmentChange} value={this.state.employeeDepartment} type="text" placeholder="Employee Department" /><br /> <br/> 
            {this.state.id ? <button className='btn btn-primary' onClick={this.submitData}>Update</button> : <button className='btn btn-primary' onClick={this.submitData}>Add</button>} &nbsp;  
             <button className='btn btn-warning' onClick={this.clearData}>CLEAR</button>  
        </table>
          </div>  

          <br/>
          <div className="rightsection">  
            <table className="table table-light">  
              <thead>  
                <tr>  
                  <th>EmployeeId</th>  
                  <th>Name</th>  
                  <th>Depatment Name</th>  
                  <th>Actions</th>  
                </tr>  
              </thead>  
              <tbody>  
                {this.props.employees && this.props.employees.map((data, index) => {  
                  return <tr key={(index)}>  
                    <td>{data.id}</td>  
                    <td>{data.employeeName}</td>  
                    <td>{data.employeeDepartment}</td>  
                    <td><button className='btn btn-primary' onClick={() => this.editDetails(data)}>Modify</button> <button className='btn btn-danger'onClick={() => this.deleteEmployee(data.id)}>Remove</button> </td>  
                  </tr>  
                })}  
              </tbody>  
            </table>  
          </div>  
        </p>  
      </div>  
    );  
  }  
}  
  
const mapStateToProps = state => ({  
  employees: state.employees  
});  
  
export default connect(mapStateToProps, { getEmployees })(Employee); 