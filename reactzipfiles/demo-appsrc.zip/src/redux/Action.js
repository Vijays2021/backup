import axios from "./axios";

const _getEmployees = (employees) => ({
    type: 'GET_EMPLOYEE',
    employees
});

export const getEmployees = () => {
    return (dispatch) => {
        return axios.get('/').then(result => {
            const employees = [];
 
            result.data.forEach(item => {
                employees.push(item);
               
            });
 
            dispatch(_getEmployees(employees));
        });
    };
};  
