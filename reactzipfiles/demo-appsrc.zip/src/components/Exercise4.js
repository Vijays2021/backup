import React, { Component } from 'react';
import Update from './Update';
import Add from './Add';
import 'bootstrap/dist/css/bootstrap.min.css';

class Exercise4 extends Component {
    constructor(props) {
        super(props);
        this.state = {
            filter: "",
            details: [
                { "fname": "Neovic", "lname": "Devierte", "address": "Silay City" },
                { "fname": "Tintin", "lname": "Cepe", "address": "Bohol" },
                { "fname": "Malet", "lname": "Cooper", "address": "Rome" }
            ],
            detail: {},
            updateFlag: false
        }

    }

    remove = (index) => {
        const current = { ...this.state };
        let newstate = current.details.filter((detail, ind) => {
            return ind !== index;
        });
        this.setState(({ details: newstate }));
    }

    update = (index) => {
        let emp = this.state.details.slice(index, index + 1)
        let newstate = this.state.details.filter((detail, ind) => {
            return ind !== index;
        });
        this.setState({ detail: emp[0], details: newstate, updateFlag: true })
    }


    // handleAdd(){
    //     this.handleAdd = this.handleAdd.bind(this);
    //     this.setState.formFlag=true
    // }



    add = (detail) => {
        let newState = [...this.state.details, detail]
        this.setState({ details: newState, updateFlag: false, formFlag: false })
    }

    searchText(event) {
        this.setState({ filter: event.target.value });
    };

    render() {

        let { filter, details } = this.state;

        let search = details.filter(item => {
            return Object.keys(item).some(key => item[key].toLowerCase().includes(filter.toLowerCase()))
        })

        return (
            <div>

                {/* <button onClick={()=>this.setState({this.props.formFlag:true})} className='btn btn-primary btn-md float-left'>+New Member</button> */}
                {this.state.updateFlag ? (<Update detail={this.state.detail} add={this.add} />) : (<Add add={this.add} />)
                }


                <br></br>

                <input type="search" placeholder="Search" value={filter} onChange={this.searchText.bind(this)}></input>
                <br /><br />
                <table className="table table-light">
                    <thead className="bg-light text-dark">
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Address</th>
                        <th>Actions</th>
                    </thead>
                    <tbody>
                        {
                            search.map((detail, ind) => {
                                return <tr key={ind}>
                                    <td>{detail.fname}</td>
                                    <td>{detail.lname}</td>
                                    <td>{detail.address}</td>
                                    <button onClick={() => { this.update(ind) }} className="btn btn-success bg-success" >Edit</button> &nbsp;
                                    <button onClick={() => { this.remove(ind) }} className="btn btn-danger bg-danger" > <i class="fa fa-trash"></i>Remove</button>
                                </tr>
                            })
                        }
                    </tbody>
                </table>
                {/* {this.state.formFlag && <Add/>} */}
            </div>
        );
    }
}

export default Exercise4;