import React, { Component } from 'react';
class Notes extends Component {
    constructor(props) {
        super(props);
        this.state = {
            name : null
         }
    }
 
delete=(index)=>{
   this.props.remove(index);
} 
    
    render() { 
        return ( <div>
                {
            
                this.props.items.map(( item , index)=>{
                    return <p key={index}>
                    {index+1}.{item.name} <button onClick={()=>{this.delete(index)}}>Remove</button> <br></br><br></br>
                </p>
                })
                }
        </div> );
    }
}
 
export default Notes;