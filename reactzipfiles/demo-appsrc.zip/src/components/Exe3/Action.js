import React, { Component } from 'react';
class Action extends Component {
    constructor(props) {
        super(props);
        this.state = { 
          
         }
    }

    handleOnChange=(event)=>{
        this.setState({[event.target.name]:event.target.value})     
     
  }
 handleOnSubmit =(event)=>{
         event.preventDefault();
        this.props.additems(this.state);
        event.target.reset();
     }
  
     removeall=()=>{
         this.props.handleRemove();
     }


    render() { 
        return ( <div>
        <form onSubmit={this.handleOnSubmit}>
        <input type="text" name="name" onChange={this.handleOnChange}/>
        <button >Add</button>
       
        </form>
       <br></br><br></br>
        <button onClick={()=>{this.removeall()}}>Remove All</button>
  
        </div> );
    }
}
 
export default Action;