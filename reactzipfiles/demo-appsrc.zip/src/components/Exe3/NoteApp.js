import React, { Component } from 'react'
import Header from './Header';
import Notes from './Notes';
import Action from './Action';

class NoteApp extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            items:[
                { "name": "This is just a note"},
                 {"name":"This is just a note"},
                 {"name":"This is just a note"}
                ]
         }
    }
    remove=(index)=>{

        let newitems = this.state.items.filter((item,ind)=>{
             return ind !== index;
        })
        this.setState({items:newitems})
}
additems=(item)=>{

    let newitems = [...this.state.items,item];
    this.setState({items: newitems})
}
handleRemove=(index)=>{

    let newstate = this.state.items.filter((i,ind)=>{
        
    });
    console.log(newstate);
    this.setState({items: newstate})
}

    render() { 
        return ( <div>
            <h1>Java Sample Approach</h1>
            <Header/> <br></br>
            <Notes items={this.state.items} remove={this.remove}/>
           
            <br></br>
            <Action additems={this.additems} items={this.state.items} handleRemove={this.handleRemove}   />
           
        </div> );
    }
}


export default NoteApp;