import React, { Component } from 'react';


class Add extends Component {
    constructor(props) {
        super(props);
        this.state = {
            fname: null,
            lname: null,
            address: null,
            formFlag: false
        }
    }

    onChange = (event) => {
        this.setState({ [event.target.name]: event.target.value })
    }

    onSubmit = (event) => {
        event.preventDefault()
        this.props.add(this.state)
        event.target.reset();
    }

    formFlag = () => {
        return (
            <div>
                <form onSubmit={this.onSubmit}>
                    First Name  :   <input type="text" name="fname" onChange={this.onChange} /><br /><br />
                    Last Name    :   <input type="text" name="lname" onChange={this.onChange} /><br /><br />
                    Address     :   <input type="text" name="address" onChange={this.onChange} /><br /><br />
                    <button className="btn btn-info">Add</button>
                </form>
            </div>
        )
    }

    render() {
        return (
            <div>
                <button onClick={() => this.setState({ formFlag: true })} className='btn btn-primary btn-md float-left' >+New Member</button>
                {this.state.formFlag ? this.formFlag() : null}
            </div>
        );
    }
}

export default Add;