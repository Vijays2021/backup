import React, { Component } from 'react';

class Update extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            fname:this.props.detail.fname,
            lname:this.props.detail.lname,
            address:this.props.detail.address
         };
    }

    onChange=(event)=>{
        this.setState({[event.target.name]:event.target.value})
    }

    onSubmit=(event)=>{
        event.preventDefault()
        this.props.add(this.state)
    }

    render() {
        return (
            <div>
                <form onSubmit={this.onSubmit}>
                    First Name  :   <input type="text" value={this.state.fname} name="fname" onChange={this.onChange}/><br/><br/>
                   Last Name    :   <input type="text" value={this.state.lname} name="lname" onChange={this.onChange}/><br/><br/>
                    Address     :   <input type="text" value={this.state.address} name="address" onChange={this.onChange}/><br/><br/>
                    <button className="btn btn-success bg-primary" >Update</button>
                </form>
            </div>
        );
    }
}

export default Update;