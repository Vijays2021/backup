import React, { Component } from 'react';
import AddCourse from './AddCourse';

class Course extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            //courses:[{"Skill1":"Java Core", "Skill2":"Spring Boot","Skill3":"AngularJS", "Skill4":"ReactJS","Skill5":"Integration"}
        courses:["Core Java", "Spring Boot", "AngularJS","ReactJS",]
        
         };
    }

    addCourse=(course)=>{

        console.log("Object Received",course);
        let newState =[...this.state.courses,course]
        console.log(newState);
        this.setState({courses:newState})
    }

    handleRemove=(index)=>{
        const current = this.state;
        let newstate = current.courses.filter((courses,ind)=>{
        });
        this.setState({courses: newstate})
    }

    render() {
        return (
            <div>
                <h2>Java Sample Approach</h2>
                <p>Categories</p>
                
                    <ol>
                        {this.state.courses.map(course=> 
                    
                        <li>{course}</li>
                    
                )}
                </ol> 
                
<AddCourse addCourse={this.addCourse}/>
<br/>
<button onClick={()=>{this.handleRemove()}} className="btn btn-danger bg-danger">Remove All</button>
            </div>
        );
    }
}

export default Course;