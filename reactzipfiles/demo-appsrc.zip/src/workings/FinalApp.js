// import logo from './logo.svg';

import './App.css';
// import Course from './components/Course';
// import StudentList from './components/StudentList';
//import Studentlist from './components/Exe4/Studentlist';
import Exercise4 from './components/Exercise4';
// import NoteApp from './components/NoteAPP/NoteApp'
import NoteApp from './components/Exe3/NoteApp';
import Employee from './redux/Employee';

function App() {
  return (
    <div className="App">
      {/* <header className="App-header"> */}
        <Employee/>
      {/* <Exercise4/> */}
        {/* <Course /> */}

        {/* <NoteApp/> */}
      {/* </header> */}
      {/* <StudentList /> */}
    </div>
  );
}

export default App;
