import React, { Component } from 'react';


class Notes extends Component {
    constructor(props) {
        super(props);
        this.state = {
            // notes:["This is just a note.", "This is just a note.", "This is just a note."]
            notes: [{ "key": "This is just a note." }, { "key": "This is just a note." }, { "key": "This is just a note." }],

        };
    }

    remove = (index) => {
        const newState = Object.assign([], this.state.notes);
        newState.splice(index, 1);
        this.setState({ notes: newState });
    }

    render() {
        return (
            <div>
                <p>JSA Notes:</p>

                <tbody>
                    {
                        this.state.notes.map((note, index) => {
                            return <tr key={index}>
                                <td>{note.key}</td>
                                <button onClick={() => { this.remove(index) }}>Remove</button>
                            </tr>
                        })
                    }

                </tbody>

            </div>

        );
    }
}

export default Notes;