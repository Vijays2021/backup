import React, { Component } from 'react';
import Header from './Header';
import Notes from './Notes';
import Action from './Action';

import './NoteApp.css';

class NoteApp extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }
    render() {
        return (
        <div>
            <Header />
            <div className='NoteApp'>
                <Notes />
            </div>
            <Action />
        </div>
        );
    }
}

export default NoteApp;