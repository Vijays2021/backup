import React, { Component } from 'react';

class Action extends Component {
    constructor(props) {
        super(props);
        this.state = {
            note:null
          };
    }
    handleOnChange=(event)=>{
        this.setState({[event.target.name]:event.target.value})
    }
    handleOnSubmit=(event)=>{
        event.preventDefault();
        this.props.action(this.state);
        event.target.reset();
    }
    handleRemove =(index) => {
        const current = this.state;
        let newstate = current.notes.filter((notes,index)=>{
        });
        this.setState({notes: newstate})
    }


    render() {
        return (
            <div>
                <form onSubmit={this.handleOnSubmit}>
                <input type="text" name="note"  onChange={this.handleOnChange} />
                <button onClick={()=>{this.handleAdd()}} className="btn btn-primary">ADD</button><br></br>
                <button onClick={()=>{this.handleRemove()}} className="btn btn-danger bg-danger">Remove All</button>

                </form>
            </div>
        );
    }
}

export default Action;