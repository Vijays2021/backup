import React, { Component } from 'react';
// import Grid from 'react-bootstrap/Container';
// import {  Row } from "react-bootstrap";
import './Header.css';

class Header extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }
    render() {
        return (
            <div className='Header'>

                {/* <Grid>
                   <Row className="text-center"><h1>Java/JavaScript Technology - Spring Framework</h1></Row>
                </Grid> */}
                <h1>Java/JavaScript Technology - Spring Framework</h1>

            </div>
        );
    }
}

export default Header;