import React, { Component } from 'react';

class UpdateStudent extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            id:this.props.student.FirstName,
            name:this.props.student.LastName,
            course:this.props.student.Address
         };
    }

    handleOnChange=(event)=>{
        this.setState({[event.target.name]:event.target.value})
    }

    handleOnSubmit=(event)=>{
        event.preventDefault()
        this.props.addStudent(this.state)
    }

    render() {
        return (
            <div>
                <form onSubmit={this.handleOnSubmit}>
                    FirstName:<input type="text" value={this.state.FirstName} name="FirstName" onChange={this.handleOnChange}/>
                    LastName:<input type="text" value={this.state.LastName} name="LastName" onChange={this.handleOnChange}/>
                    Address:<input type="text" value={this.state.Address} name="Address" onChange={this.handleOnChange}/>
                    <button>Update</button>
                </form>
            </div>
        );
    }
}

export default UpdateStudent;