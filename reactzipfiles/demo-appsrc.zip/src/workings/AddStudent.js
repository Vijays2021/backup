import React, { Component } from 'react';

class AddStudent extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            FirstName:null,
            LastName:null,
            Address:null
         };

    }

    handleOnChange=(event)=>{
        console.log(event.target)
        console.log(event.target.value)
        this.setState({[event.target.name]:event.target.value})
    }

    handleOnSubmit=(event)=>{
        event.preventDefault();
        console.log(this.state);
        this.props.addStudent(this.state);
        event.target.reset();
    }

    render() {
        return (
            <div className="container" >
                
                <form onSubmit={this.handleOnSubmit} className="form-group" >
                    <label > First Name </label> &nbsp; &nbsp;
                    <input type="text" name="FirstName" onChange={this.handleOnChange} /><br/><br/>
                    <label> Last Name </label>&nbsp; &nbsp;
                    <input type="text" name="LastName" onChange={this.handleOnChange} /><br/><br/>
                    <label> Address </label>&nbsp;&nbsp;
                    <input type="text" name="Address" onChange={this.handleOnChange} /><br/><br/>
                    <button className="btn btn-info">Save</button>
                </form>
            </div>
        );
    }
}

export default AddStudent;