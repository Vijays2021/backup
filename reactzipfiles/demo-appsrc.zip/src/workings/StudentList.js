import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import AddStudent from './AddStudent';
import UpdateStudent from './UpdateStudent';

class StudentList extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            students:[{"FirstName":"Neovic","LastName":"Devierte","Address":"Silay City"},
            {"FirstName":"Julyn","LastName":"Divingracia","Address":"E.B. Magaiona"}],
            student:{},
            updateFlag:false
         };
    }
    handleRemove=(index)=>{
        const current =this.state;
        let newstate = current.students.filter((student,ind)=>{
            return ind !== index;
        });
        this.setState(state =>({students: newstate}))
    }

    handleEdit=(index)=>{
        let emp = this.state.students.slice(index,index+1)
       // console.log(emp);
        let newstate = this.state.students.filter((student,ind)=>{
            
            return ind !== index;
            console.log(newstate);
        });
        this.setState({student:emp[0],students:newstate,updateFlag:true})
    }

addStudent=(student)=>{

    console.log("Object Received",student);
    let newState =[...this.state.students,student]
    this.setState({students:newState})
}

    render() {
        return (
            <div>
                    {/* <h1>StudentList</h1> */}
                    <button className='btn btn-primary'>+ New Member</button>
                    <table className="table ">
                        <thead className="bg-info text-white">
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Address</th>
                            <th colSpan="2">Action</th>
                        </thead>
                        <tbody>
                            {
                                this.state.students.map((student, ind)=>{
                                    return <tr key={ind}>
                                                <td>{student.FirstName}</td>
                                                <td>{student.LastName}</td>
                                                <td>{student.Address}</td>
    <button onClick={()=>{this.handleEdit(ind)}} className="btn btn-primary bg-info">Edit</button> &nbsp; &nbsp;
    <button onClick={()=>{this.handleRemove(ind)}} className="btn btn-danger bg-danger">Remove</button>

                                            </tr>
                                })
                            }
                        </tbody>
                    </table>

                    <h1>Student Registration Form</h1>   
                         
                    {/* <AddStudent addStudent={this.addStudent}/> */}
                    {this.state.updateFlag?(<UpdateStudent student={this.state.student} addStudent={this.addStudent}/>):(<AddStudent addStudent={this.addStudent}/>)
    }
            </div>       
        );
    }
}

export default StudentList; 