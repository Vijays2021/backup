
import './App.css';
import React, { Component } from 'react';
//import course from './components/course';

class App extends Component {
 constructor(props){
   super(props);
   this.state={
     count:0
   }
 }

 increment = () =>{
   this.setState({count:this.state.count + 1});
 }

 decrement = () =>{
  this.setState({count:this.state.count - 1});
}

render(){
  return(
     <div className="App">
         <h2>Counter: {this.state.count}</h2>
         <button onClick={this.increment} className="counter">ADD+</button>
       <  button onClick={this.decrement} className="counter">MINUS-</button>      
     </div>
//    <course/>
  );
}

}

export default App;
