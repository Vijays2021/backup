import React, { Component } from 'react';
import './App.css';
import axios from 'axios';
import EmployeeList from './component/emplist';
import NewEmployee from './component/newemp';
import EditEmployee from './component/editemp';
import { BrowserRouter as Router, Routes, Route, Link, Outlet } from 'react-router-dom';
import Home from './component/Home';
//import Exercise4 from '../../demo-app/src/components/Exercise4';


// const api = axios.create({
//   baseURL:'http://localhost:3000/courses/'
// })



class App extends Component {
  constructor() {
    super();
    // api.get('/').then(res =>{
    //   console.log(res.data)
    // })
  }


  render() {

    return (
      <Router>
        <div className="App">
          <Routes>
            <Route path="/" element={<Home />}>
              <Route path="/emplist" element={<EmployeeList />} />
              <Route path="/newemp" element={<NewEmployee />} />
              <Route path=":id/editemp" element={<EditEmployee/>} />
              {/* <Route path="/CRUD" element={<Exercise4/>}/> */}
            </Route>
          </Routes>


        </div>
      </Router>
    );
  }
}
export default App;
