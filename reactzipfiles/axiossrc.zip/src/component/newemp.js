import React, { useState } from 'react';
import axios from 'axios';

const NewEmployee = () => {

    const [empname, processName] = useState("");
    const [empmobile, processMobile] = useState("");
    const [empdept, processDept] = useState("");
    const [empsalary, processSalary] = useState("");
    const [message, processMessage] = useState("");


    const save = () => {
        //  alert(empname);
        var empinfo = {
            "name": empname,
            "mobile": empmobile,
            "dept": empdept,
            "salary": empsalary
        };
        const url = "http://localhost:3002/employee";
        axios.post(url, empinfo)
            .then(response =>
                processMessage(empname + " Saved Successfully!")

            )
        processName("");
        processMobile("");
        processDept("");
        processSalary("");
    }

    return (
        <div>
            <h1>Add new Employee</h1>
            <p>{message}</p>
            <table id="newemp" cellPadding="10">
                <tr>
                    <th>Employee Name</th>
                    <td>
                        <input type="text" className="inputbox"
                            value={empname}
                            onChange={obj => processName(obj.target.value)}
                        ></input>
                    </td>
                </tr>
                <tr>
                    <th>Mobile No</th>
                    <td>
                        <input type="text" className='inputbox'
                            value={empmobile}
                            onChange={obj => processMobile(obj.target.value)}
                        ></input>
                    </td>
                </tr>
                <tr>
                    <th>Department</th>
                    <td>
                        <input type="text" className='inputbox'
                            value={empdept}
                            onChange={obj => processDept(obj.target.value)}

                        ></input>
                    </td>
                </tr>
                <tr>
                    <th>Salary</th>
                    <td>
                        <input type="text" className='inputbox'
                            value={empsalary}
                            onChange={obj => processSalary(obj.target.value)}

                        ></input>
                    </td>
                </tr>
                <tr>
                    <th colSpan="2">
                        <button onClick={save}>Save Employee</button>
                    </th>
                </tr>

            </table>
        </div>
    )
}

export default NewEmployee;