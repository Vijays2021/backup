import React, { Component } from 'react';
import { Link, Outlet } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';



class Home extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }
    render() {
        return (
            <div>
                <h1>Routing Demo</h1>

                <Link className='btn btn-primary' to="/emplist" >Employee data </Link> &nbsp;
                <Link to="/newemp" className='btn btn-primary'>Add Employee </Link>
                {/* <Link to="/CRUD"  className='btn btn-primary'>CRUD</Link> */}

                <Outlet />

            </div>

        );
    }
}

export default Home;