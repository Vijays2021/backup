import React,{useState, useEffect} from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
const EditEmployee= () =>{
    const{id} = useParams();

    const [empname, processName] = useState("");
    const [empmobile, processMobile] = useState("");
    const [empdept, processDept] = useState("");
    const [empsalary, processSalary] = useState("");
    const [message, processMessage] = useState("");

    const getEmpinfo =() =>{
        const url = "http://localhost:3002/employee/"+id;
        axios.get(url).then(response=>{
            processName(response.data.name);
            processMobile(response.data.mobile);
            processDept(response.data.dept);
            processSalary(response.data.salary);
        })
    }
    useEffect(() =>{
        getEmpinfo();
    }, [true])

    const updateEmp = () =>{
        var empinfo = {
            "name": empname,
            "mobile": empmobile,
            "dept": empdept,
            "salary": empsalary
        };
        const url = "http://localhost:3002/employee/" +id;
        axios.put(url, empinfo).then(response =>{
            processMessage(empname + " Updated Successfully");
        })
    }

    return(
        <div>
            <h1>Edit Employee details : {id} </h1>
            <p>{message}</p>
            <table id="newemp" cellPadding="10">
                <tr>
                    <th>Employee Name</th>
                    <td>
                        <input type="text" className="inputbox"
                            value={empname}
                            onChange={obj => processName(obj.target.value)}
                        ></input>
                    </td>
                </tr>
                <tr>
                    <th>Mobile No</th>
                    <td>
                        <input type="text" className='inputbox'
                            value={empmobile}
                            onChange={obj => processMobile(obj.target.value)}
                        ></input>
                    </td>
                </tr>
                <tr>
                    <th>Department</th>
                    <td>
                        <input type="text" className='inputbox'
                            value={empdept}
                            onChange={obj => processDept(obj.target.value)}

                        ></input>
                    </td>
                </tr>
                <tr>
                    <th>Salary</th>
                    <td>
                        <input type="text" className='inputbox'
                            value={empsalary}
                            onChange={obj => processSalary(obj.target.value)}

                        ></input>
                    </td>
                </tr>
                <tr>
                    <th colSpan="2">
                        <button onClick={updateEmp} >Update Employee</button>
                    </th>
                </tr>

            </table>

        </div>
    )
}

export default EditEmployee;