import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {Link} from 'react-router-dom';

const EmployeeList = () => {
    const url = "http://localhost:3002/employee";
    const [emplist, updateEmp] = useState([]);
    const getEmp = () => {
        fetch(url).then(response => response.json())
            .then(allEmp => updateEmp(allEmp))
    }

    useEffect(() => {
        getEmp();
    },)

    const [message, updateMessage] = useState("");
    const deleteEmp = (empid) => {
        //alert (empid);
        axios.delete("http://localhost:3002/employee/" + empid)
            .then(response => {
                updateMessage("Employee info Deleted successfully !");
                getEmp();
            }).catch(error => {
                updateMessage("Error! Try again later");

            })

    }
    return (
        <div>

            <h1>Available Employee : {emplist.length}</h1>
            <p align="center">{message}</p>
            <table id="emplist">
                <thead>
                    <tr bgcolor="dodgerblue">
                        <th>Employee ID</th>
                        <th>Employee Name</th>
                        <th>Mobile</th>
                        <th>Department</th>
                        <th>Salary</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        emplist.map((empinfo, index) => {
                            return (
                                <tr key={index}>
                                    <td>{empinfo.id}</td>
                                    <td>{empinfo.name}</td>
                                    <td>{empinfo.mobile}</td>
                                    <td>{empinfo.dept}</td>
                                    <td>{empinfo.salary}</td>
                                    <td>
                                        <Link className='btn' to={`/${empinfo.id}/editemp`}>Edit</Link>
                                        <button onClick={deleteEmp.bind(this, empinfo.id)}
                                            className='danger'>Delete</button>
                                    </td>
                                </tr>
                            )
                        })
                    }
                </tbody>
            </table>
        </div>
    )
}

export default EmployeeList;