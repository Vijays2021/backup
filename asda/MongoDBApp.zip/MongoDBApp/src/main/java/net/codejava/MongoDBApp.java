package net.codejava;

import org.bson.Document;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoIterable;

public class MongoDBApp {

	public static void main(String[] args) {
		MongoClient mongoClient = MongoClients.create();
		
		MongoIterable<String> dbNames =  mongoClient.listDatabaseNames();
		for (String dbname : dbNames) {
			System.out.println(dbname);
		}
		
		MongoDatabase db = mongoClient.getDatabase("codejava");
		MongoCollection<Document> collection = db.getCollection("inventory");
		
		//Document document = new Document("name","MotoG");
		//collection.insertOne(document);
		
		FindIterable<Document> result = collection.find();
		
		for(Document document : result) {
			System.out.println(document.toJson());
		}
		
	}

}
