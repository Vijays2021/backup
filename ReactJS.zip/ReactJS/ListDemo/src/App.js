import './App.css';
import NameList from './Component/NameList';
import PersonList from './Component/PersonList';

function App() {
  return (
    <div className="App">
      <NameList/>
      <PersonList/>
    </div>
  );
}

export default App;
