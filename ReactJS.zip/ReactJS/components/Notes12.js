import React, { Component } from 'react';

class Notes12 extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            items:[
            { "id": "This is just a note"},
             {"id":"This is just a note"},
             {"id":"This is just a note"}
            ]
         }

    }
    
    remove=(index)=>{
            let newitems = this.state.items.filter((item,ind)=>{
                 return ind !== index;
            })
            this.setState({items:newitems})
    }
   additems=(item)=>{
    let newstate = [...this.state. items,item]//here we are coping into the new array
    this.setState({ items : newstate });
   }
    render() { 
        return ( <div>
            JSA Notes:
              {
                  this.state.items.map((items,index)=>{
                      return <li key={index}>
                         {index}.{items.id} <button onClick={()=>{this.remove(index)}}>Remove</button> <br></br><br></br>
                     </li>
                  })
              }
           
        </div> );
    }
}
 
export default Notes12;
