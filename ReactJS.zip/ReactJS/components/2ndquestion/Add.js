import React, { Component } from 'react';
import Addcategory from './Addcategory';
import mystyle from './styles.css';
class Add extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            categories:[{"course":"Java Core"},
            {"course":"Spring Boot"},
            {"course":"AngularJs"},
            {"course":"ReactJs"},
            {"course":"Integration"}],


         };
    }
    handleRemove=(index)=>{
        const current = this.state;
        let newstate = current.categories.filter((categories,ind)=>{
        });
        //console.log(newstate)
        this.setState({categories: newstate})
    }

    addCategory=(category)=>{
        console.log("received object", category)
        let newState=[...this.state.categories,category]
        this.setState({categories:newState})
    }

    
    render() {
        return (
            <div className="sample">
            <h1>Java Sample Approach</h1>
            <h4>Categories:</h4>
                <p className="mystyle" >
                    {
                        this.state.categories.map((categories)=>{
                            return  <p>
                                <h6>{categories.course}</h6>
                                </p>
                        })
                    }
                </p> 
                    <Addcategory addCategory={this.addCategory}/>
                    <br/>
                    <button onClick={()=>{this.handleRemove()}}>RemoveAll</button>
        </div>
            
        );
    }
}

export default Add;