import React, { Component } from 'react';


class Addcategory extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            course:null
         };
    }

    handleOnChange=(event)=>{
        console.log(event.target);
        console.log(event.target.value);
        this.setState({[event.target.name]:event.target.value})
    }

    handleOnSubmit=(event)=>{
        event.preventDefault();
        console.log(this.state)
        this.props.addCategory(this.state);
    }
    render() {
        return (
            <div>
                <form onSubmit={this.handleOnSubmit}>
                    <input type="text" name="course" onChange={this.handleOnChange}/>
                    <button>Add</button>
                </form>
            </div>
        );
    }
}

export default Addcategory;