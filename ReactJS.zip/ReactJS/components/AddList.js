import React, { Component } from "react";


 class AddList extends Component {
  state = {
    cart: ["Shiva", "Sai"],
  };

  saveInput = (e) => {
    this.setState({ input: e.target.value });
  };

  addNewItem = () => {
    this.setState({cart: this.state.cart.concat(this.state.input)});
  };
  // removeall =()=>{

  // }

  render() {
    return (
      <div>
        <li>
          {
          this.state.cart.map((subItems, index) => {
            return <li key={index}> 
            {subItems}
            </li>
          })
          }
        </li>
        <input type="text" onChange={this.saveInput}/>
        <button onClick={this.addNewItem}> Add Item </button>
        {/* <button onClick={this.removeall}> Remove All </button> */}
        
      </div>
    );
  }
}

export default AddList;