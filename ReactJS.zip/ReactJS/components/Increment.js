import React, { Component } from 'react';

export class Increment extends Component {
    constructor(props){
        super(props);
        this.state={
            name : "vamshi",
            age : 26,
            occupation : "developer",
            count :0
        };
    }

    handleincrement = () =>{
        this.setState({ count : ++this.state.count })
    }
    handledrecrement =() =>{        
            this.setState({count : --this.state.count})
    }

    render() {
        return (
            <div> 
                <div>Employee Name : {this.state.name}</div>
                <div>Employee age : {this.state.age}</div>
                <div>Employee occupation : {this.state.occupation}</div>
                <div>  Count Value :  
                    {
                   this.state.count  > 0 ? ( <h4>{this.state.count} </h4> ) :( <h4>0</h4>   )
                    } 

                   
                    </div>
              
                <button type="button" className='btn btn-primary' onClick={this.handleincrement}>Increment </button>&nbsp; &nbsp;
                <button type="button"  className='btn btn-primary' onClick={this.handledrecrement} >Decrement</button>
            </div>
           
        )
    }
}

export default Increment

