import React, { Component } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import AddStudent from './AddStudent';
import UpdateStudentlist from './UpdateStudentlist';


class Studentlist extends Component {
    constructor(props){
        super(props);
        this.state = { 
            students : [
                {"id" : "26836","Firstname": "Vamshi","course" : "C++"}, 
                {"id" : "26837","Firstname": "Akhil","course" : "Java"}, 
                {"id" : "26838","Firstname": "Kalayan","course" : "English"}, 
                {"id" : "26839","Firstname": "Sunil","course" : "PHP"}   
             ],
             student:{},
             updateFlag :false
        };
    }
     //delete method
    delete=(index)=>{
        console.log(index);
       let newstate  = this.state.students.filter((student,ind)=>{
           return ind !== index;
       });
       this.setState({students : newstate });
    }

    //Edit method or upadate
   edit=(index)=>{
       let std = this.state.students.slice(index,index+1);
       console.log("edit value",std[0]);
       let newstate  = this.state.students.filter((student,ind)=>{
        return ind !== index;
    });
    this.setState({student:std[0] , students:newstate,updateFlag:true});
   }

   
    //addstudent menthod
   addStudent=(student)=>{
           console.log("Recived from the AddStudent Component  :",student);
          let newstate = [...this.state.students,student]//here we are coping into the new array
          this.setState({students : newstate, updateFlag:false });//here new array was assinging to students array

   }

    render() {
        return (
            <div>
                  <table  class="table">
                    <thead >
                        <th>ID</th>
                        <th>FristName</th>
                        <th>Course</th>
                        <th>Action</th>
                    </thead>
                    <tbody>
                        {
                        this.state.students.map((student,index)=>{
                            return <tr key={index}>
                                <td>{student.id}</td>
                                <td>{student.Firstname}</td>
                                <td>{student.course}</td>
                                <td><button type="button" onClick={()=>{this.edit(index)}} class="btn btn-info">Edit</button> &nbsp; &nbsp;
                                <button type="button" onClick={()=>{this.delete(index)}} class="btn btn-danger">Delete</button></td>
                            </tr>
                        })}
                    </tbody>
                </table>

               
                {this.state.updateFlag ? (<UpdateStudentlist student={this.state.student} addStudent={this.addStudent}/>):(<AddStudent addStudent={this.addStudent}/>)}

                
                
            </div>
        )
    }
}

export default Studentlist