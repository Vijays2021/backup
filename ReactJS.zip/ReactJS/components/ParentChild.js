import React from 'react'

const ParentChild = (props) => { 
    return(
        <div>
            <div>Employee Name : {props.employeelist.name} </div>
            <div>Employee Age : {props.employeelist.age}</div>
            <div>Employee occupation : {props.employeelist.occupation}</div>
        </div>
       
    )

}
export default ParentChild;