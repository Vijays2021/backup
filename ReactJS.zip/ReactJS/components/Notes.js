import React, { Component } from 'react';
class Notes extends Component {
    constructor(props) {
        super(props);
        this.state = {
            name : null
         }
    }
 
delete=(index)=>{
   this.props.remove(index);
} 
    
    render() { 
        return ( <div>
                {
            
                this.props.items.map(( item , index)=>{
                    return <li key={index}>
                        {console.log("items",item)}
                    {index+1}.{item.name} <button onClick={()=>{this.delete(index)}}>Remove</button> <br></br><br></br>
                </li>
                })
                }
        </div> );
    }
}
 
export default Notes;