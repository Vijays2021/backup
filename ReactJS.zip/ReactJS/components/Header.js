import React, { Component } from 'react'
class Header extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( <div>
            <h1>Java/javaScript Technology-Spring Framework </h1>
        </div> );
    }
}
 
export default Header;