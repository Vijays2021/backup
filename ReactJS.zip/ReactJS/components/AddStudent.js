import React, { Component } from 'react';

class AddStudent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      id: null,
      Fristname: null,
      course: null

    }
  }

  handleOnChange = (event) => {
    this.setState({ [event.target.name]: event.target.value })
    //for every change in the textbox it will update
  }
  handleOnSubmit = (event) => {
    event.preventDefault();//It is used for not to reload the page
    console.log(this.state);
    this.props.addStudent(this.state);
  }

  render() {
    return (
      <div className='container'>
        <form onSubmit={this.handleOnSubmit}>
                           ID :<input type="text" name="id" onChange={this.handleOnChange}/><br></br><br></br>
                           FirstName :<input type="text" name="Firstname" onChange={this.handleOnChange}/><br></br><br></br>
                           Course : <input type="text" name="course" onChange={this.handleOnChange} /><br></br><br></br>
                       <button >Add </button>
              </form>  
      </div>
    );
  }
}

export default AddStudent;


{/* 
     
            
            
            
              <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
          Add Member
        </button>

        
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                ...
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
              </div>
            </div>
          </div>
        </div>
            
            */}