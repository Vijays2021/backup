import React from 'react'

const Employee = () => {
    let  name = "Shiva"
    let  age = "24"
    let  occupation = "UI/Ux"
    return (
        <div>
            <div>Employee Name : {name}</div>
            <div>Employee age : {age}</div>
            <div>Employee occupation :{occupation}</div>
        </div>
    )
}
export default Employee;