import React, { Component } from 'react'
import Header from './Header';
import Notes from './Notes';
import Action from './Action';
import Notes12 from './Notes12';
class NoteApp extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            items:[
                { "name": "This is just a note"},
                 {"name":"This is just a note"},
                 {"name":"This is just a note"}
                ]
         }
    }
    remove=(index)=>{
        console.log("delete index value :",index);
        let newitems = this.state.items.filter((item,ind)=>{
             return ind !== index;
        })
        this.setState({items:newitems})
}
additems=(item)=>{
    console.log("Recived from Action : ",item)
    let newitems = [...this.state.items,item];
    this.setState({items: newitems})
}
handleRemove=(index)=>{

    let newstate = this.state.items.filter((i,ind)=>{
        
    });
    console.log(newstate);
    this.setState({items: newstate})
}

    render() { 
        return ( <div>
            <h1>Java Sample Approach</h1>
            <Header/> <br></br>
            <Notes items={this.state.items} remove={this.remove}/>
            {/* <Notes12 /> */}
            <br></br>
            <Action additems={this.additems} items={this.state.items} handleRemove={this.handleRemove}   />
           
        </div> );
    }
}


export default NoteApp;