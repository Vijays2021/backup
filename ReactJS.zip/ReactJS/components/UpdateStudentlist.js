import React, { Component } from 'react'
class UpdateStudentlist extends Component {
    constructor(props) {
        super(props);
        this.state = { 
         id: this.props.student.id,
         Firstname:this.props.student.name,
         course: this.props.student.course
         }
    }


    handleOnChange=(event)=>{
        this.setState({[event.target.name]:event.target.value})     
     //for every change in the textbox it will update
  }
 handleOnSubmit =(event)=>{
         event.preventDefault();//It is used for not to reload the page
         console.log("updated values:",this.state);
         this.props.addStudent(this.state);
     }
    render() { 
        return (  
        <div>
           <form onSubmit={this.handleOnSubmit}>
                  ID :<input type="text" name="id" value={this.state.id} onChange={this.handleOnChange}/><br></br>
                  FristName :<input type="text" name="name" value={this.state.Firstname} onChange={this.handleOnChange}/><br></br>
                  Course : <input type="text" name="course" value={this.state.course} onChange={this.handleOnChange} /><br></br>
                  <button >Update</button>
              </form>
        </div>
        );
    }
}
 
export default UpdateStudentlist;