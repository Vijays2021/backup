import React, { Component } from 'react';
class Action extends Component {
    constructor(props) {
        super(props);
        this.state = { 
          
         }
    }

    handleOnChange=(event)=>{
        this.setState({[event.target.name]:event.target.value})     
     //for every change in the textbox it will update
  }
 handleOnSubmit =(event)=>{
         event.preventDefault();//It is used for not to reload the page
         console.log("Text box",this.state);
        this.props.additems(this.state);
     }
  
     removeall=()=>{
         this.props.handleRemove();
     }


    render() { 
        return ( <div>
        <form onSubmit={this.handleOnSubmit}>
        <input type="text" name="name" onChange={this.handleOnChange}/>
        <button >Add</button>
       
        </form>
       <br></br><br></br>
        <button onClick={()=>{this.removeall()}}>Remove All</button>
  
        </div> );
    }
}
 
export default Action;