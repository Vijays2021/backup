import React, { Component } from 'react';

class UpdateStudent extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            id:this.props.student.id,
            name:this.props.student.name,
            course:this.props.student.course
         };
    }

    handleOnChange=(event)=>{
        this.setState({[event.target.name]:event.target.value})
    }

    handleOnSubmit=(event)=>{
        event.preventDefault()
        this.props.addStudent(this.state)
    }

    render() {
        return (
            <div>
                <form onSubmit={this.handleOnSubmit}>
                    Id:<input type="text" value={this.state.id} name="id" onChange={this.handleOnChange}/>
                    Name:<input type="text" value={this.state.name} name="name" onChange={this.handleOnChange}/>
                    Course:<input type="text" value={this.state.course} name="course" onChange={this.handleOnChange}/>
                    <button>Update</button>
                </form>
            </div>
        );
    }
}

export default UpdateStudent;