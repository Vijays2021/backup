import React from 'react';
import './App.css';
/* The following line can be included in your src/index.js or App.js file*/
import 'bootstrap/dist/css/bootstrap.min.css';
import StudentList from './Component/StudentList';
import User from './User/User';

function App() {
  return (
    <div>      
      <StudentList/>
      <User/>
    </div>
  );
}

export default App;
