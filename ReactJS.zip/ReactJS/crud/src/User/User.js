import React from 'react';
const User = () => {
    return (
        <div>
            Hi this is User Component
        </div>
    );
}

export default User;