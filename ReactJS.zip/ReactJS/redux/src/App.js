//App.js
import React from 'react';
import './App.css';
import {BrowserRouter,Switch,Route} from 'react-router-dom'
import DashBoard from './components/Dashboard';
import AddBook from './components/AddBook';
import EditBook from './components/EditBook';
import Header from './components/Header';

const NotFound = () => {
  return (
    <>
    <h1>Sorry...Page Not found</h1>
    </>
  );
}



function App() {
  return (
    <BrowserRouter>
    <div className='container'>
        <Header/>
        <Switch>
            <Route path="/" component={DashBoard} exact={true} />
            <Route path="/add" component={AddBook} />
            <Route path="/book/:id" component={EditBook} />
            <Route component={NotFound} />
        </Switch>
    </div>
</BrowserRouter>
  );
}

export default App;
