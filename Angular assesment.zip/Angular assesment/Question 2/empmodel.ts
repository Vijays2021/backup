export class EmpModel {

    skillset:string;
    name:string;
    address:string;
    email:string;
    mobileno:string;
    acceptTerms : string;

    constructor(skillset:string="",name:string="",address:string="",email:string="",mobileno:string="", acceptTerms:string=""){
        this.skillset=skillset;
        this.name=name;
        this.address=address;
        this.email=email;
        this.email=email;
        this.mobileno=mobileno;
        this.acceptTerms =acceptTerms;
    }
}