import { Component, OnInit } from '@angular/core';
import { EmpModel } from './empmodel';

@Component({
  selector: 'app-empform',
  templateUrl: './emp.component.html',
  styleUrls: ['./emp.component.css']
})
export class Contactform1Component  {

    addStatus :any;
    empModel : EmpModel;
    skillsets:string[];

  constructor() { 
    this.empModel=new EmpModel();
    this.skillsets=["Angular","RPA","Networking","BigData"];
    this.addStatus ={}
  }

}