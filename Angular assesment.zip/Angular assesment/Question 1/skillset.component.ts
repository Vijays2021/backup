import { Component } from "@angular/core";
import { Skillset } from "./skillset";


@Component({
      selector:"skillset",
      templateUrl:"./skillset.component.html"
})

export class SkillsetComponent{

    skillset:Skillset[];
    name: string;
    email : string;
    
    constructor(){
        this.skillset=[
            new Skillset("Angular"),
            new Skillset("RPA"),
            new Skillset("Networking"),
            new Skillset("Bigdata")
        ];
    }
    onSelected(skillset:Skillset):void{
        this.name=skillset.name;
		this.email=skillset.email;
        console.log(this.name + this.email);
    }

}