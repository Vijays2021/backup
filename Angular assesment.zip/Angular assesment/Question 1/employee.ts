export class Employee{

employeeName :string;
email : string;


constructor(employeeName:string="",email:string="",)
{
this.employeeName=employeeName;
this.email=email;

}


}