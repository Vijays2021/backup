import { Pipe, PipeTransform } from '@angular/core';
import { Employees } from 'employees';

@Pipe({
  name: 'employeefilter'
})
export class EmployeefilterPipe implements PipeTransform {

  transform(employee:employeeList[],skillset:skillset[]){
    if(!skillset){
      return employeeList;
    }
    return employeeList.filter(skillset=>employee.skillset==skillset);
  }

}
