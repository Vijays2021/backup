export class Skillset{

    skillset:string;
    name:string;
    email:string;

    constructor(skillset:string="",name:string="",email:string=""){
        this.skillset=skillset;
        this.name=name;
        this.email=email;
    }

}