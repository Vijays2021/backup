import { Component, Input } from "@angular/core";
import { Employees } from "./employees";


@Component({
    selector:"employee",
    templateUrl:"./employees.component.html"
})

export class EmployeesComponent{
    EmployeesList:Employees[];
   
    @Input()
    email: string;
    skillset :string;

    constructor(){
        this.EmployeesList=[
            new Employees("Vijay","vijay@gmail.com","Angular"),
            new Employees("Ajith","ajith@gmail.com","Bigdata"),
            new Employees("vikram","vikram@gmail.com","RPA"),
            new Employees("Surya","surya@gmail.com","Networking"),
            new Employees("Rajini","rajini@gmail.com","RPA"),
            new Employees("Kamal","kamal@gmail.com","Bigdata"),
            
        ];
    }
}