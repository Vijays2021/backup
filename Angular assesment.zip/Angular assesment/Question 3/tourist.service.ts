import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable,pipe,throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { TouristModel } from '../assessment/touristmodel';

@Injectable({
  providedIn: 'root'
})
export class TouristService {

  httpOptions ={
    headers :new HttpHeaders({
      'Content-Type':'application/json'
    })
  }

  constructor(private httpclient :HttpClient) { }

  getPlaces(state :string):Observable<TouristModel>{
    return this.httpclient.get<TouristModel>('http://localhost:8080/TourAdvisor/TouristPlaces/States/'+state)
    .pipe(
      retry(2),
      catchError(this.handleError)
    );
  }
  
  private handleError(error: HttpErrorResponse) {
    if (error.status === 0) {
      console.error('Client error occurred:', error.error);
    } else {
      console.error(
        `Backend returned code ${error.status}, body was: `, error.error);
    }
    return throwError(
      'Something bad happened; please try again later.');
  }
}