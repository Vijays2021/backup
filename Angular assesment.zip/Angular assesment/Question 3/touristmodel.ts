export class touristModel {
tourAdvisor:string;
touristPlaces:string;
state: string;

    constructor(tourAdvisor:string="",touristPlaces:string="",state:string=""){
        this.tourAdvisor=tourAdvisor;
        this.touristPlaces=touristPlaces;
        this.state=state;
    }
}