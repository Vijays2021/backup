import { Component, OnInit } from '@angular/core';
import { TouristService } from '../services/contact1.service';
import { TouristModel } from './touristModel';

@Component({
  selector: 'app-searchplaces',
  templateUrl: './searchplaces.component.html',
  styleUrls: ['./searchplaces.component.css']
})
export class SearchplacesComponent {
  state:string;
  touristModel: TouristModel;
  statusmessage: string = "";
  fetchstatus: boolean = true;

  constructor(private touristService: TouristService) {
    this.state="";
    this.touristModel = new TouristModel();
    this.statusmessage = "Loading..."
  }

  searchPlaces(): void {
    this.touristService.getPlaces(this.state)
                 .subscribe((res) => {
                             this.fetchstatus = true;
                             this.touristModel = res;
                             console.log(res);
                               },

                             (errResp) => {
                                  this.fetchstatus = false;
                                    this.statusmessage = "error loading---";
                                          }
                            );
  }

}