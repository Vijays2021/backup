# Image-Hosting

## To download just 1 single folder,
   * go to the desired folder, 
   * copy the url, 
   * go to [downgit](https://minhaskamal.github.io/DownGit/#/home) & 
   * follow the steps on the video 👇 ->

![](https://cloud.githubusercontent.com/assets/5456665/17822364/940bded8-6678-11e6-9603-b84d75bccec1.gif)



# Project Part of This Video 

https://youtu.be/hwJKjsZUPjY

[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/hwJKjsZUPjY/maxresdefault.jpg
)](https://youtu.be/hwJKjsZUPjY)


## Image credits : 

   * [cute-girl](https://www.pexels.com/photo/woman-lying-on-plants-2125610/)
   * [cute-bear](https://www.freepik.com/free-vector/cute-bear-is-happy-cartoon-illustration_12341167.htm#position=4)
   * [kitty-avatar](https://www.flaticon.com/packs/kitty-avatars-3)
